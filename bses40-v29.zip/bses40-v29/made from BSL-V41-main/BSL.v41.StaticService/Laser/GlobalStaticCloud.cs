﻿namespace BSL.v41.StaticService.Laser;

public static class GlobalStaticCloud
{
    public static string? PragmaAndServerEnvironment { get; set; }
}