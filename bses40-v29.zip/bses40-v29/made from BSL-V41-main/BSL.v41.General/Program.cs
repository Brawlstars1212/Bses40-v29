﻿using BSL.v41.Titan.Graphic;

namespace BSL.v41.General;

public static class Program
{
    public static void Main(string[] args)
    {
        ConsoleLogger.WriteTextWithPrefix(ConsoleLogger.Prefixes.Cmd, "Emulation of 'General' has been launched.");
    }
}