﻿namespace BSL.v41.General.NetIsland.LaserBattle.Significant.Attack;

public class LogicAttackSpecialParams
{
    // todo.
}