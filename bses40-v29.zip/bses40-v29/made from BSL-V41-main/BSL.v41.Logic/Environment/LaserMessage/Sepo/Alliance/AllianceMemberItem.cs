﻿namespace BSL.v41.Logic.Environment.LaserMessage.Sepo.Alliance;

public class AllianceMemberItem
{
    // todo.
}