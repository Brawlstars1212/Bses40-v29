﻿using BSL.v41.Titan.Mathematical.Pull;

namespace BSL.v41.Titan.Utilities.Structs;

public class Stru5Fffc : Elf32_Rel
{
    public override uint rOffset { get; set; } = 12536720u;
    public override uint rInfo { get; set; } = 23u;
}